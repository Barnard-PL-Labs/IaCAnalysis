exports.handler = (event, context, callback) => {
    // TODO implement
    console.log(event);

    callback(null, 'Hello from Lambda');
};